
package Relatorio;

import Modelo.HospedeDAO;
import java.awt.Desktop;
import java.io.File;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import modelo.ConnectionFactory;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class ControleJasperSoft {
    private String url = "file:/C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg";
    
    public void consulta1 (Date d){
        Connection connection = ConnectionFactory.getConnection();
        
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/Gisele1.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL", "C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
            parameters.put("dataCheckin", d);

            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/Gisele1.pdf");
            
            //JasperViewer jv = new JasperViewer(jp, false);
            
            //jv.setVisible(true);
            
            File arquivo = new File("././Report/Gisele1.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
    
    public void consulta2 (Date d){
        Connection connection = ConnectionFactory.getConnection();
        
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/Gisele2.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL", "C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
            parameters.put("dataCheckin1", d);
              parameters.put("dataCheckin2", d);

            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/Gisele2.pdf");
            
            JasperViewer jv = new JasperViewer(jp, false);
            
            jv.setVisible(true);
            
            File arquivo = new File("././Report/Gisele2.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
    
    public void consulta3 (int codigo){
        Connection connection = ConnectionFactory.getConnection();
        
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/Gisele3.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL", "C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
            parameters.put("CodigoReserva", codigo);
            

            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/Gisele3.pdf");
            
            JasperViewer jv = new JasperViewer(jp, false);
            
            jv.setVisible(true);
            
            File arquivo = new File("././Report/Gisele3.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
    
    public void consulta4 (Date d){
        
        Connection connection = ConnectionFactory.getConnection();
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/Hosp_2.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL", "C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
            
            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/Hosp.pdf");
            
            JasperViewer jv = new JasperViewer(jp, false);
            
            jv.setVisible(true);
            
            File arquivo = new File("././Report/Hosp.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
    
    public void consulta5(Date d){
        Connection connection = ConnectionFactory.getConnection();
        
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/funcionario.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL", "C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
            

            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/funcionario.pdf");
            
            JasperViewer jv = new JasperViewer(jp, false);
            
            jv.setVisible(true);
            
            File arquivo = new File("././Report/funcionario.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
    
    public void consulta6(Date d){
        Connection connection = ConnectionFactory.getConnection();
        
        JasperPrint jp = null;
        try {

            String sourceName = "././Report/ProdutoConsumo_9.jasper";
            Map parameters = new HashMap();
            
            parameters.put("imgURL","C:\\Users\\alunos\\Documents\\NetBeansProjects\\Trabalho jasperSoft\\SistemaH\\src\\visao\\icon\\logoSist.jpg");
           

            jp = JasperFillManager.fillReport(sourceName, parameters, connection);
            
            JasperExportManager.exportReportToPdfFile(jp, "././Report/ProdutoConsumo_9.pdf");
            
            JasperViewer jv = new JasperViewer(jp, false);
            
            jv.setVisible(true);
            
            File arquivo = new File("././Report/ProdutoConsumo_9.pdf");
            Desktop.getDesktop().open(arquivo);
        } catch (Exception e) {
            System.out.println("Erro:");
            e.printStackTrace();
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Gabriela
 */
public class ReservaBEAN {

    private String hrEnt;
    private String hrSai;
    private String numero;
    private String dias;
    private String desconto;
    private String codAP;
    private String codHosp;

    public String getCodHosp() {
        return codHosp;
    }

    public void setCodHosp(String codHosp) {
        this.codHosp = codHosp;
    }

    public String getValorPago() {
        return valorPago;
    }

    public void setValorPago(String valorPago) {
        this.valorPago = valorPago;
    }
    private String valorPago;
    private String ac1;
    private String ac2;
    private String ac3;
    private String ac4;
    private String ac5;
    private String ac6;

    public String getHrEnt() {
        return hrEnt;
    }

    public void setHrEnt(String hrEnt) {
        this.hrEnt = hrEnt;
    }

    public String getHrSai() {
        return hrSai;
    }

    public void setHrSai(String hrSai) {
        this.hrSai = hrSai;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDias() {
        return dias;
    }

    public void setDias(String dias) {
        this.dias = dias;
    }

    public String getDesconto() {
        return desconto;
    }

    public void setDesconto(String desconto) {
        this.desconto = desconto;
    }

    public String getCodAP() {
        return codAP;
    }

    public void setCodAP(String codAP) {
        this.codAP = codAP;
    }

    public String getAc1() {
        return ac1;
    }

    public void setAc1(String ac1) {
        this.ac1 = ac1;
    }

    public String getAc2() {
        return ac2;
    }

    public void setAc2(String ac2) {
        this.ac2 = ac2;
    }

    public String getAc3() {
        return ac3;
    }

    public void setAc3(String ac3) {
        this.ac3 = ac3;
    }

    public String getAc4() {
        return ac4;
    }

    public void setAc4(String ac4) {
        this.ac4 = ac4;
    }

    public String getAc5() {
        return ac5;
    }

    public void setAc5(String ac5) {
        this.ac5 = ac5;
    }

    public String getAc6() {
        return ac6;
    }

    public void setAc6(String ac6) {
        this.ac6 = ac6;
    }

    public String getAc7() {
        return ac7;
    }

    public void setAc7(String ac7) {
        this.ac7 = ac7;
    }

    public String getAc8() {
        return ac8;
    }

    public void setAc8(String ac8) {
        this.ac8 = ac8;
    }

    public String getAc9() {
        return ac9;
    }

    public void setAc9(String ac9) {
        this.ac9 = ac9;
    }
    private String ac7;
    private String ac8;
    private String ac9;

}
